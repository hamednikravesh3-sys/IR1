# NV v0.5 Build-safe

هدف این نسخه این است که بتوان قبل از اتصال SDKهای سنگین نقشه و Routing،
یک APK قابل Build از رابط NV گرفت.

## چه چیزی تغییر کرد
- وابستگی مستقیم MapLibre از مسیر اصلی Build حذف شد.
- لایه MapLibre با NvMapPreview داخلی جایگزین شد تا External SDK باعث شکست Build نشود.
- رابط Responsive v0.4 حفظ شد.
- لایه نمایشی مسیر، جاده‌ها، ترافیک، glow و vehicle marker اضافه شد.
- GitHub Actions برای ساخت خودکار debug APK اضافه شد.
- minSdk=29، targetSdk=35 و JDK 17 حفظ شد.

## مهم
این نسخه برای گرفتن APK و بررسی UI است.
برای نقشه واقعی ایران، GPS واقعی روی خیابان، Valhalla و Offline routing،
در نسخه production باید MapLibre/Valhalla را مجدداً به‌صورت کنترل‌شده و تست‌شده اضافه کرد.
