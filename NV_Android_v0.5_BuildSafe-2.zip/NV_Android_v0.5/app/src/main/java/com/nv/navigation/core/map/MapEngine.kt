package com.nv.navigation.core.map

import com.nv.navigation.core.model.GeoPoint

enum class MapMode { TWO_D, THREE_D }
enum class BaseLayer { VECTOR, TERRAIN, SATELLITE }

interface MapEngine {
    fun setMode(mode: MapMode)
    fun setBaseLayer(layer: BaseLayer)
    fun setTrafficVisible(visible: Boolean)
    fun setNightMode(enabled: Boolean)
    fun moveCamera(point: GeoPoint, bearing: Double, pitch: Double, zoom: Double)
}

/**
 * Implement with MapLibre Native for Android.
 * Keep styles and data providers independent from the engine.
 */
class MapLibreMapEngine : MapEngine {
    override fun setMode(mode: MapMode) = Unit
    override fun setBaseLayer(layer: BaseLayer) = Unit
    override fun setTrafficVisible(visible: Boolean) = Unit
    override fun setNightMode(enabled: Boolean) = Unit
    override fun moveCamera(point: GeoPoint, bearing: Double, pitch: Double, zoom: Double) = Unit
}
