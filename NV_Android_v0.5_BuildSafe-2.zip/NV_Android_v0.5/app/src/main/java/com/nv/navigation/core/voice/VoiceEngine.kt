package com.nv.navigation.core.voice

enum class VoiceLanguage { FA, EN }

interface VoiceEngine {
    suspend fun speak(text: String, language: VoiceLanguage)
    fun stop()
}
