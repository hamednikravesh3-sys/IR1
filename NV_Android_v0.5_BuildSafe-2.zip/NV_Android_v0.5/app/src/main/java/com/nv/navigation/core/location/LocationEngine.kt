package com.nv.navigation.core.location

import com.nv.navigation.core.model.GeoPoint
import kotlinx.coroutines.flow.Flow

data class LocationFix(
    val point: GeoPoint,
    val speedMps: Float?,
    val bearingDegrees: Float?,
    val accuracyMeters: Float
)

interface LocationEngine {
    val fixes: Flow<LocationFix>
}

interface MapMatcher {
    suspend fun match(fix: LocationFix): MatchedRoad?
}

data class MatchedRoad(
    val roadId: String,
    val snappedPoint: GeoPoint,
    val directionDegrees: Float,
    val confidence: Double
)
