package com.nv.navigation.core.offline

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class IranOfflineManifest(
    val version: String,
    val mapUrl: String,
    val routingGraphUrl: String,
    val searchIndexUrl: String,
    val poiUrl: String,
    val voiceFaUrl: String?,
    val sha256: Map<String, String> = emptyMap()
)

data class DownloadProgress(
    val component: String,
    val bytesDownloaded: Long,
    val totalBytes: Long?,
    val completed: Boolean
)

/**
 * Production downloader skeleton.
 * Download to app-scoped files, verify checksum, then atomically promote.
 * Resume/range support and WorkManager integration should be added before production.
 */
class IranOfflinePackageManager(private val context: Context) {

    private fun rootDir(): File =
        File(context.filesDir, "nv_offline/iran").apply { mkdirs() }

    suspend fun downloadFile(
        component: String,
        url: String,
        onProgress: (DownloadProgress) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val target = File(rootDir(), "$component.part")
        val finalFile = File(rootDir(), component)

        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            instanceFollowRedirects = true
        }

        conn.inputStream.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(256 * 1024)
                var read: Int
                var total = 0L
                val length = conn.contentLengthLong.takeIf { it > 0L }
                while (input.read(buffer).also { read = it } >= 0) {
                    if (read == 0) continue
                    output.write(buffer, 0, read)
                    total += read
                    onProgress(DownloadProgress(component, total, length, false))
                }
            }
        }

        if (finalFile.exists()) finalFile.delete()
        if (!target.renameTo(finalFile)) {
            target.copyTo(finalFile, overwrite = true)
            target.delete()
        }
        onProgress(DownloadProgress(component, finalFile.length(), finalFile.length(), true))
        finalFile
    }

    fun installedFile(name: String): File? =
        File(rootDir(), name).takeIf { it.exists() }
}
