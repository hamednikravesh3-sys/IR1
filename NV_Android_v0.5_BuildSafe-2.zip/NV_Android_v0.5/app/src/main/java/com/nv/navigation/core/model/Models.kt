package com.nv.navigation.core.model

data class GeoPoint(val lat: Double, val lon: Double)

data class NamedPlace(
    val nvCode: Long,
    val nameFa: String,
    val nameEn: String? = null,
    val point: GeoPoint,
    val type: String
)

enum class RouteKind { SMART, FASTEST, SHORTEST, ECO, LOW_TRAFFIC }

data class RouteMetrics(
    val distanceMeters: Double,
    val durationSeconds: Double,
    val trafficDelaySeconds: Double = 0.0,
    val unpavedMeters: Double = 0.0,
    val tollMeters: Double = 0.0,
    val riskScore: Double = 0.0,
    val weatherPenalty: Double = 0.0,
    val energyScore: Double = 0.0
)

data class RouteCandidate(
    val id: String,
    val kind: RouteKind,
    val metrics: RouteMetrics,
    val polyline: List<GeoPoint> = emptyList(),
    val explanationFa: String = ""
)

data class DriverPreferences(
    val avoidTolls: Boolean = false,
    val avoidHighways: Boolean = false,
    val avoidUnpaved: Boolean = true,
    val preferEco: Boolean = false
)
