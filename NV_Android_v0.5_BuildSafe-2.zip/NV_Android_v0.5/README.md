# NV Navigation — Android Starter

این بسته، پایه‌ی فنی پروژه NV برای Android 10+ است و با Kotlin + Jetpack Compose طراحی شده است.

## اصل معماری
`Offline Navigation Core + Online Live Services + AI Intelligence`

## آنچه در این نسخه وجود دارد
- پروژه Android با minSdk 29 (Android 10)
- رابط RTL فارسی و Map-first prototype
- سرچ نام/NV Code با دکمه پاک‌کردن
- مبدأ طراحی‌شده برای GPS فعلی
- نمایش 3 گزینه مسیر: هوشمند، سریع‌ترین، کوتاه‌ترین
- قراردادهای Map / Routing / Traffic / Weather / POI / Voice / GPS / Subscription
- الگوریتم پایه امتیازدهی چندهدفه NV Smart Route
- Foreground Navigation Service
- مدل Trial/Subscription/Admin و اصول ضد سوءاستفاده در سمت سرور
- لوگوی ارسالی NV به‌عنوان asset پروژه

## نکته مهم
این بسته «اسکلت مهندسی واقعی» است، نه ادعای یک مسیریاب تولیدی کامل. برای تکمیل نسخه نهایی باید MapLibre Native،
داده نقشه ایران، گراف Valhalla، دیتابیس جست‌وجو/NV Code، سرویس ترافیک، Weather provider، TTS آفلاین،
API زرین‌پال و Backend واقعی متصل شوند.

## Build
پروژه را در Android Studio باز کنید، JDK 17 را انتخاب کنید و Gradle Sync بزنید.
سپس `app` را روی دستگاه Android 10+ اجرا کنید.

به دلیل اینکه محیط تولید این فایل Android SDK/Gradle wrapper نداشت، APK در همین مرحله کامپایل نشده است.


## v0.2
رابط رانندگی جدید نزدیک به تصویر مرجع NV اضافه شد: HUD کامل، مسیر زنده، پنل مسیرها، Weather/POI rail و Bottom Navigation.


## v0.3
MapLibre واقعی پشت HUD رانندگی قرار گرفت و پایه دانلود آفلاین ایران و اتصال Valhalla اضافه شد. برای اجرای کامل آفلاین، دیتاست ایران و binaryهای Valhalla باید در محیط build واقعی متصل شوند.


## v0.5 Build-safe
این شاخه برای گرفتن APK کم‌ریسک طراحی شده است. MapLibre از Build اصلی جدا شده و GitHub Actions فایل app-debug.apk را می‌سازد.
